import cxf.demo.TypeFunctionProcessFactoryBean;
import cxf.demo.TypeFunctionProcess;
import org.junit.Test;

/**
 * @author cxf
 * @create 2019-11-24 12:41
 * @desc
 **/
public class TypeFunctionProcessTests {


}
