package cxf.demo;

/**
 * @author cxf
 * @create 2019-11-24 12:27
 * @desc
 **/
public interface Process {

	void process(Object o);
}
